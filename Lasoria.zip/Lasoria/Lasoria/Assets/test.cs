﻿using UnityEngine;
using System.Collections;

public class test : MonoBehaviour {

	LineRenderer lineRenderer;
	public Material xyz;
	private int count = 1;
	private int maxIterations = 3;
	private float maxDistance = 10f;
	Ray ray;
	RaycastHit hit;

	// Use this for initialization
	void Start () {
		lineRenderer = GetComponent<LineRenderer> ();

	}
	
	// Update is called once per frame
	void Update () {
		//count = 1;
		ray = new Ray(transform.position, transform.up);
		hit = new RaycastHit ();
		Physics.Raycast (ray, out hit);
//		lineRenderer.enabled = RayCast(new Ray(transform.position, transform.forward));
//		Vector3.Reflect (ray.direction, hit.normal);

		lineRenderer.SetVertexCount (10);

		lineRenderer.enabled = true;         
		lineRenderer.SetPosition (0, transform.position); 
		//	lineRenderer.SetPosition(1, hit.point);
		lineRenderer.material = xyz;
		lineRenderer.SetWidth (0.2f, 0.2f);
		//lineRenderer.SetPosition (2, Vector3.Reflect (ray.direction, hit.normal));
		//lineRenderer.SetColors (Color.blue, Color.blue);

		if (Physics.Raycast (ray, out hit, 10)) {
			Reflect (count);
		}

//		lineRenderer.material = xyz;
//		lineRenderer.S	etWidth (0.2f, 0.2f);
	
	}

	void Reflect( int c){
		count ++;
		lineRenderer.SetPosition (c, hit.point);
		ray = new Ray (hit.point, Vector3.Reflect (hit.point, hit.normal));
	}

//	private bool RayCast(Ray ray) {
//		RaycastHit hit;
//		if (Physics.Raycast(ray, out hit, maxDistance) && count <= maxIterations - 1) {
//			count++;
//			var reflectAngle = Vector3.Reflect(ray.direction, hit.normal);
//			lineRenderer.SetVertexCount(count + 1);
//			lineRenderer.SetPosition(count, hit.point);
//			RayCast(new Ray(hit.point, reflectAngle));
//			return true;
//		}
//		lineRenderer.SetVertexCount(count + 2);
//		lineRenderer.SetPosition(count + 1, ray.GetPoint(maxDistance));
//		return false;
//	}

}
