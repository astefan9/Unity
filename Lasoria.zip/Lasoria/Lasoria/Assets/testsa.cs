﻿using UnityEngine;
using System.Collections;

public class testsa : MonoBehaviour {

	LineRenderer lineRenderer;
	public Material xyz;
	private int count = 0;
	
	Ray ray;
	RaycastHit hit;

	
	// Use this for initialization
	void Start () {
		lineRenderer = GetComponent<LineRenderer> ();
//		ray = new Ray(transform.position, transform.up);
//		hit = new RaycastHit ();
//		Physics.Raycast (ray, out hit);
		lineRenderer.SetVertexCount (1);
		
		lineRenderer.enabled = true;         
		lineRenderer.SetPosition (0, transform.position); 
		lineRenderer.material = xyz;
		lineRenderer.SetWidth (0.2f, 0.2f);
	}
	
	// Update is called once per frame
	void Update () {
	
		ray = new Ray(transform.position, transform.up);
		hit = new RaycastHit ();
		Physics.Raycast (ray, out hit);
		
//		lineRenderer.SetPosition (2, Vector3.Reflect(ray.direction,hit.normal));

		if (Physics.Raycast (ray, out hit)) {
			lineRenderer.SetVertexCount (2);
			lineRenderer.SetPosition (1, hit.point);

			if (hit.transform.gameObject.tag != "NO") {
				Ray ray2 = new Ray (hit.point, Vector3.Reflect (ray.direction, hit.normal));
				RaycastHit hit2 = new RaycastHit ();
				Physics.Raycast (ray2, out hit2);

				if (Physics.Raycast (ray2, out hit2)) {
					lineRenderer.SetVertexCount (3);
					lineRenderer.SetPosition (2, hit2.point);

					if (hit2.transform.gameObject.tag != "NO") {
						Ray ray3 = new Ray (hit2.point, Vector3.Reflect (ray2.direction, hit2.normal));
						RaycastHit hit3 = new RaycastHit ();
						Physics.Raycast (ray3, out hit3);

						if(Physics.Raycast (ray3, out hit3)) {
							lineRenderer.SetVertexCount (4);
							lineRenderer.SetPosition(3, hit3.point);

							if(hit3.transform.gameObject.tag != "NO")
							{
								Ray ray4 = new Ray(hit3.point, Vector3.Reflect (ray3.direction, hit3.normal));
								RaycastHit hit4 = new RaycastHit();
								Physics.Raycast (ray4, out hit4);

								if(Physics.Raycast (ray4, out hit4))
								{
									lineRenderer.SetVertexCount (5);
									lineRenderer.SetPosition(4, hit4.point);

									if(hit4.transform.gameObject.tag != "NO")
									{
										Ray ray5 = new Ray (hit4.point, Vector3.Reflect (ray4.direction, hit4.normal));
										RaycastHit hit5 = new RaycastHit();
										Physics.Raycast (ray5, out hit5);

										if(Physics.Raycast(ray5, out hit5))
										{
											lineRenderer.SetVertexCount (6);
											lineRenderer.SetPosition(5, hit5.point);

											if(hit5.transform.gameObject.tag != "NO")
											{
												Ray ray6 = new Ray (hit5.point, Vector3.Reflect (ray5.direction, hit5.normal));
												RaycastHit hit6 = new RaycastHit();
												Physics.Raycast (ray6, out hit6);
											}
										}
										else
										{
											lineRenderer.SetVertexCount(5);
										}
									}
								}

								else
								{
									lineRenderer.SetVertexCount (4);
								}
							}
						}
						else 
						{
							lineRenderer.SetVertexCount (3);
						}
					} 
				}
					else {
						lineRenderer.SetVertexCount (2);
					}
				
			}
		}
		else {
			lineRenderer.SetVertexCount (1);
		}

		// scene switch
		int x = Application.loadedLevelName.ToString ();

		if (hit.transform.gameObject.tag == "Winner" || hit2.transform.gameObject.tag == "Winner" || hit3.transform.gameObject.tag == "Winner" || hit4.transform.gameObject.tag == "Winner" || hit5.transform.gameObject.tag == "Winner" || hit6.transform.gameObject.tag == "Winner") {
			Application.LoadLevel((x + 1).ToString());
		}
	}
}
