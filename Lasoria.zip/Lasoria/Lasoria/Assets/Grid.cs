﻿using UnityEngine;
using System.Collections;

public class Grid : MonoBehaviour {
	public GameObject a;
	public GameObject b;
	int length = 0;
	int width = 0;
	Color c = new Color(130f, 0f, 0f);


	// Use this for initialization
	void Start () {
		a.GetComponent<Renderer>().material.color = c;
		b.GetComponent<Renderer>().material.color = Color.black;
		GameObject [,] back = new GameObject [30,15];

		while (length < 30) {

			while (width < 15) {
				if(length %2 == 0) {
					if (width % 2 == 0)
					{back [length,width] = (GameObject) Instantiate (a, new Vector2 (length * 1f, width * 1f), Quaternion.identity);}
					else if (width % 2 == 1)
					{back [length,width] = (GameObject) Instantiate (b, new Vector2 (length * 1f, width * 1f), Quaternion.identity);}
				}
				else if(length %2 == 1) {
					if (width % 2 == 0)
					{back [length,width] = (GameObject) Instantiate (a, new Vector2 (length * 1f, width * 1f - 1f), Quaternion.identity);}
					else if (width % 2 == 1)
					{back [length,width] = (GameObject) Instantiate (b, new Vector2 (length * 1f, width * 1f - 1f), Quaternion.identity);}
				}
				width++;
			}
			width = 0;
			length++;
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
